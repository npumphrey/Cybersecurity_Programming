def clean_phone_numbers(numbers):
    # TODO: Create a function that accepts a list of strings and returns a list that consists of valid 10-digit North American phone numbers
    for i in range(len(numbers)):
        clean = ''
        for num in numbers[i]:
            if num in '0123456789':
                clean += num
        numbers[i] = clean
    
    j = len(numbers) - 1
    while j >= 0:
        if len(numbers[j]) != 10:
            del numbers[j]
        j -= 1
            
    print(f"{len(numbers)} valid phone numbers were found.")


def find_number(numbers, search_term):
    # TODO: Create a function that accepts a list and a search term and returns information about whether or not th appears in the list
    # This function searches for an entire US phone number
    count = 0
    match = []
    for x in numbers:
        if x == search_term:
            count += 1
            match.append(x)

    print(f"The phone number was found {count} times in the list of phone numbers: ['{match}']")



def find_areacode(numbers, search_term):
    # TODO: Create a function that accepts a list and a search term and returns information about whether or not th appears in the list
    # This function searches for the area code of a phone number
    count = 0
    match = []
    for x in numbers:
        if x[0:3] == search_term:
            count += 1
            match.append(x)

    print(f"The phone number was found {count} times in the list of phone numbers: ['{match}']")



def find_exchange(numbers, search_term):
    # TODO: Create a function that accepts a list and a search term and returns information about whether or not th appears in the list
    # This function searches for the exchange of a phone number
    count = 0
    match = []
    for x in numbers:
        if x[3:6] == search_term:
            count += 1
            match.append(x)

    print(f"The phone number was found {count} times in the list of phone numbers: ['{match}']")

