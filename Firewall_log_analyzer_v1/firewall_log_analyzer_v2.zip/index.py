from log_analyzer import LogEntry
from csv import DictReader
import argparse
import pytz




def arg_accepter():
    parser = argparse.ArgumentParser(description='Accept CSV file')

    parser.add_argument('--CSVfile', '-c', required=True, help='CSV file')
    args=parser.parse_args()

    return args

def main():
    args = arg_accepter()
    print(args.CSVfile)
    
    logs = []
    with open(args.CSVfile, 'r') as f:
        
        dict_reader = DictReader(f)
        # Create an iterable element that will hold the contents of the CSV file as a list
        # This will result in a LIST OF DICTIONARIES
        list_of_dict = list(dict_reader)

        for d in list_of_dict:
            entry = LogEntry(d['event_time'], d['internal_ip'], d['port_number'], d['protocol'], d['action'], d['rule_id'], d['country'], d['country_name'], d['source_ip'])
            logs.append(entry)
        
        est_timezone = pytz.timezone("US/Eastern")
        for i in range(5):
            pytz_logs = est_timezone.localize(logs[i].event_time)
            
            
            print(f"{pytz_logs}, {logs[i].action}, {logs[i].source_ip}, {logs[i].ipv4_class}, {logs[i].country_name}")


        
                
        


    

if __name__ == '__main__':
    main()