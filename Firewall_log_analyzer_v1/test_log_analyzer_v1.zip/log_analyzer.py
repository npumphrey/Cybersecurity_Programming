from datetime import datetime
import re
    
class LogEntry():
    
    def __init__(self, event_time: datetime, internal_ip, port_number, protocol, action, rule_id, country, country_name, source_ip: int):
        
        self.event_time = event_time
        self.internal_ip = internal_ip
        self.port_number = port_number
        self.protocol = protocol
        self.action = action
        self.rule_id = rule_id
        self.country = country
        self.country_name = country_name
        self.source_ip = source_ip

        # et_string = "2022-01-01 00:18:38 UTC"
        format_string = "%Y-%m-%d %H:%M:%S %Z"
        et = datetime.strptime(event_time, format_string)



    @property
    def ipv4_class(self):
        group_octects = re.search(r"(\d{1,3})", self.source_ip)
        first_octet = int(group_octects.group())
        if first_octet <= 127:
            ip_class = 'A'
            return ip_class
        elif first_octet >= 128 and first_octet <= 191:
            ip_class = 'B'
            return ip_class
        elif first_octet >= 192 and first_octet <= 223:
            ip_class = 'C'
            return ip_class
        elif first_octet >= 224 and first_octet <= 239:
            ip_class = 'D'
            return ip_class
        else:
            ip_class = 'E'
            return ip_class